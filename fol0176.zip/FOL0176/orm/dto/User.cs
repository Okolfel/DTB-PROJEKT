﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreIS.orm.dto
{
    public class User
    {
        public int user_id { get; set; }
        public String name { get; set; }
        public String surname { get; set; }
        public Char Role { get; set; }
        public Char Licence { get; set; }
        public String street { get; set; }
        public String zip { get; set; }
        public String city { get; set; }
        public String country { get; set; }
        public String password { get; set; }
        public String phone { get; set; }
        public String mail { get; set; }
    }
}
