-- Store Database, Database System II
-- May, 7, 2024
-- db.cs.vsb.cz

drop table OrderItem;
drop table "Order";
drop table "User";
drop table Supply;
drop table Staff;
drop table ProductPrice;
drop table Product;






